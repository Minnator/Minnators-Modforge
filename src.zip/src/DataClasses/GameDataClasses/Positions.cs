﻿namespace Editor.DataClasses.GameDataClasses
{
   public class Positions
   {
      public Point City { get; set; }
      public Point Text { get; set; }
      public Point Port { get; set; }
      public Point TradeNodeModel { get; set; }
   }
}