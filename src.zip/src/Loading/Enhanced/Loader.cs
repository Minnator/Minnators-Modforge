﻿namespace Editor.Loading.Enhanced
{
   public abstract class Loader
   {
      public abstract void Load();
   }
}