﻿namespace Editor.Loading.Enhanced
{
   public static class LoadMaster
   {
      
   }
}