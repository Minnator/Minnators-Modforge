﻿namespace Editor.DiscordGame_SDK
{
    public partial class ActivityManager
    {
        public void RegisterCommand()
        {
            RegisterCommand(null);
        }
    }
}
