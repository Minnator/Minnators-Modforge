﻿namespace Editor.DiscordGame_SDK
{
    static class Constants
    {
        public const string DllName = "discord_game_sdk";
    }
}
